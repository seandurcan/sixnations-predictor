import { cookies } from "next/headers";
import { prisma } from "@/lib/prisma";

const SESSION_COOKIE_NAME = "sixnations_session";

export async function getCurrentSession() {
  const cookieStore = await cookies();

  const sessionToken =
    cookieStore.get(
      SESSION_COOKIE_NAME
    )?.value;

  if (!sessionToken) {
    return null;
  }

  const session =
    await prisma.session.findUnique({
      where: {
        token: sessionToken,
      },
      include: {
        user: true,
      },
    });

  if (!session) {
    return null;
  }

  if (
    session.expiresAt.getTime() <
    Date.now()
  ) {
    await prisma.session.delete({
      where: {
        id: session.id,
      },
    });

    return null;
  }

  return session;
}

export async function getCurrentUser() {
  const session =
    await getCurrentSession();

  return session?.user ?? null;
}

export async function requireUser() {
  const user =
    await getCurrentUser();

  if (!user) {
    throw new Error(
      "Authentication required"
    );
  }

  return user;
}

export async function requireAdmin() {
  const user =
    await requireUser();

  if (user.role !== "ADMIN") {
    throw new Error(
      "Admin access required"
    );
  }

  return user;
}

export async function createSession(
  userId: number
) {
  const token =
    crypto.randomUUID() +
    crypto.randomUUID();

  const expiresAt = new Date();

  expiresAt.setDate(
    expiresAt.getDate() + 30
  );

  const session =
    await prisma.session.create({
      data: {
        token,
        userId,
        expiresAt,
      },
    });

  return session;
}

export async function destroySession() {
  const cookieStore = await cookies();

  const sessionToken =
    cookieStore.get(
      SESSION_COOKIE_NAME
    )?.value;

  if (!sessionToken) {
    return;
  }

  await prisma.session.deleteMany({
    where: {
      token: sessionToken,
    },
  });
}

export const SESSION_COOKIE =
  SESSION_COOKIE_NAME;