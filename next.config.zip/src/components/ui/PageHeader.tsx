type PageHeaderProps = {
  title: string;
  subtitle?: string;
  className?: string;
};

export default function PageHeader({
  title,
  subtitle,
  className = "",
}: PageHeaderProps) {
  return (
    <div className={`mb-5 ${className}`}>
      <h1 className="text-3xl font-bold text-[var(--brand-navy)]">
        {title}
      </h1>

      {subtitle && (
        <p className="mt-1 text-sm text-[var(--brand-muted)]">
          {subtitle}
        </p>
      )}
    </div>
  );
}