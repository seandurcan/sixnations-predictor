import { ReactNode } from "react";

type CardProps = {
  children: ReactNode;
  title?: string;
  className?: string;
};

export default function Card({
  children,
  title,
  className = "",
}: CardProps) {
  return (
    <div
      className={`bg-white border border-[var(--brand-border)] rounded-xl shadow-sm p-4 transition-shadow duration-200 hover:shadow-md ${className}`}
    >
      {title && (
        <h2 className="text-lg font-bold mb-3 text-[var(--brand-navy)]">
          {title}
        </h2>
      )}

      {children}
    </div>
  );
}