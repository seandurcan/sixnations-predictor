"use client";

import Button from "@/components/ui/Button";
import Card from "@/components/ui/Card";
import CountdownTimer from "@/components/ui/CountdownTimer";
import PageHeader from "@/components/ui/PageHeader";
import StatCard from "@/components/ui/StatCard";
import {
  formatIrishDate,
  formatIsoDate,
} from "@/lib/formatIrishDate";
import { useEffect, useState } from "react";

type User = {
  id: string | number;
  firstName?: string | null;
};

type AuthResponse = {
  authenticated?: boolean;
  user?: User | null;
};

type LeaderboardRow = {
  id: string | number;
  rank?: number | null;
  rankMovement?: number | null;
  totalPoints?: number | null;
  differenceScore?: number | null;
  exactScores?: number | null;
};

type LeaderboardResponse = {
  data?: LeaderboardRow[];
};

type Team = {
  name: string;
};

type Match = {
  id: string | number;
  round?: number | null;
  kickoffTime?: string | null;
  completed: boolean;
  homeTeam: Team;
  awayTeam: Team;
  actualHomeScore?: number | null;
  actualAwayScore?: number | null;
};

type Prediction = {
  id?: string | number;
  matchId?: string | number | null;
  updatedAt?: string | null;
  pointsAwarded?: number | null;
  differenceScore?: number | null;
};

function redirectTo(path: string) {
  window.location.href = path;
}

function sameId(
  first: string | number | null | undefined,
  second: string | number | null | undefined
) {
  if (
    first === null ||
    first === undefined ||
    second === null ||
    second === undefined
  ) {
    return false;
  }

  return String(first) === String(second);
}

function getTimestamp(
  value: string | null | undefined,
  fallback: number
) {
  if (!value) {
    return fallback;
  }

  const timestamp = new Date(value).getTime();

  return Number.isFinite(timestamp)
    ? timestamp
    : fallback;
}

async function readJson<T>(
  response: Response,
  description: string
): Promise<T> {
  try {
    return (await response.json()) as T;
  } catch {
    throw new Error(
      `${description} returned invalid JSON.`
    );
  }
}

export default function DashboardPage() {
  const [user, setUser] =
    useState<User | null>(null);

  const [leaderboard, setLeaderboard] =
    useState<LeaderboardRow[]>([]);

  const [userRow, setUserRow] =
    useState<LeaderboardRow | null>(null);

  const [nextMatch, setNextMatch] =
    useState<Match | null>(null);

  const [predictionCount, setPredictionCount] =
    useState(0);

  const [matchCount, setMatchCount] =
    useState(0);

  const [lastMatch, setLastMatch] =
    useState<Match | null>(null);

  const [lastPrediction, setLastPrediction] =
    useState<Prediction | null>(null);

  const [loading, setLoading] =
    useState(true);

  useEffect(() => {
    let cancelled = false;

    async function initialise() {
      try {
        const meResponse =
          await fetch("/api/auth/me");

        if (meResponse.ok === false) {
          redirectTo("/login");
          return;
        }

        const me =
          await readJson<AuthResponse>(
            meResponse,
            "Authentication API"
          );

        if (
          !me.authenticated ||
          !me.user
        ) {
          redirectTo("/login");
          return;
        }

        const currentUser = me.user;

        const leaderboardResponse =
          await fetch(
            "/api/leaderboard?page=1&pageSize=500"
          );

        if (
          leaderboardResponse.ok === false
        ) {
          throw new Error(
            "Unable to load the leaderboard."
          );
        }

        const leaderboardData =
          await readJson<LeaderboardResponse>(
            leaderboardResponse,
            "Leaderboard API"
          );

        const leaderboardRows =
          Array.isArray(
            leaderboardData.data
          )
            ? leaderboardData.data
            : [];

        const currentUserRow =
          leaderboardRows.find((row) =>
            sameId(
              row.id,
              currentUser.id
            )
          ) ?? null;

        const matchesResponse =
          await fetch("/api/matches");

        if (matchesResponse.ok === false) {
          throw new Error(
            "Unable to load the fixtures."
          );
        }

        const matchesData =
          await readJson<unknown>(
            matchesResponse,
            "Matches API"
          );

        const matches =
          Array.isArray(matchesData)
            ? (matchesData as Match[])
            : [];

        const sortedUpcomingMatches =
          matches
            .filter(
              (match) => !match.completed
            )
            .sort(
              (first, second) =>
                getTimestamp(
                  first.kickoffTime,
                  Number.MAX_SAFE_INTEGER
                ) -
                getTimestamp(
                  second.kickoffTime,
                  Number.MAX_SAFE_INTEGER
                )
            );

        const sortedCompletedMatches =
          matches
            .filter(
              (match) => match.completed
            )
            .sort(
              (first, second) =>
                getTimestamp(
                  second.kickoffTime,
                  Number.MIN_SAFE_INTEGER
                ) -
                getTimestamp(
                  first.kickoffTime,
                  Number.MIN_SAFE_INTEGER
                )
            );

        const latestCompletedMatch =
          sortedCompletedMatches[0] ??
          null;

        const predictionsResponse =
          await fetch(
            "/api/predictions/list"
          );

        if (
          predictionsResponse.ok === false
        ) {
          throw new Error(
            "Unable to load predictions."
          );
        }

        const predictionsData =
          await readJson<unknown>(
            predictionsResponse,
            "Predictions API"
          );

        const predictions =
          Array.isArray(predictionsData)
            ? (predictionsData as Prediction[])
            : [];

        const sortedPredictions =
          [...predictions].sort(
            (first, second) =>
              getTimestamp(
                second.updatedAt,
                Number.MIN_SAFE_INTEGER
              ) -
              getTimestamp(
                first.updatedAt,
                Number.MIN_SAFE_INTEGER
              )
          );

        const predictionForLatestResult =
          latestCompletedMatch
            ? sortedPredictions.find(
                (prediction) =>
                  sameId(
                    prediction.matchId,
                    latestCompletedMatch.id
                  )
              ) ??
              sortedPredictions[0] ??
              null
            : null;

        if (cancelled) {
          return;
        }

        setUser(currentUser);
        setLeaderboard(
          leaderboardRows
        );
        setUserRow(currentUserRow);
        setMatchCount(matches.length);
        setNextMatch(
          sortedUpcomingMatches[0] ??
            null
        );
        setLastMatch(
          latestCompletedMatch
        );
        setPredictionCount(
          predictions.length
        );
        setLastPrediction(
          predictionForLatestResult
        );
      } catch (error) {
        console.error(
          "Dashboard load failed:",
          {
            timestamp:
              formatIsoDate(
                new Date()
              ),
            error,
          }
        );

        if (!cancelled) {
          redirectTo("/login");
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    void initialise();

    return () => {
      cancelled = true;
    };
  }, []);

  function renderMovement() {
    const movement =
      userRow?.rankMovement;

    if (
      movement === undefined ||
      movement === null
    ) {
      return "-";
    }

    if (movement > 0) {
      return `↑ ${movement}`;
    }

    if (movement < 0) {
      return `↓ ${Math.abs(
        movement
      )}`;
    }

    return "→";
  }

  function getWelcomeSubtitle() {
    const firstName =
      user?.firstName?.trim() ||
      "Player";

    if (!userRow) {
      return `Welcome ${firstName}`;
    }

    return (
      `Welcome ${firstName} · ` +
      `Ranked #${userRow.rank ?? "-"} ` +
      `of ${leaderboard.length} players`
    );
  }

  const rankMovement =
    userRow?.rankMovement ?? 0;

  if (loading) {
    return (
      <main className="mx-auto max-w-7xl bg-white p-6 text-[var(--brand-navy)]">
        <PageHeader
          title="Dashboard"
          subtitle="Loading your dashboard..."
        />

        <Card>
          Loading dashboard...
        </Card>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-7xl bg-white p-6 text-[var(--brand-navy)]">
      <PageHeader
        title="Dashboard"
        subtitle={getWelcomeSubtitle()}
      />

      <div className="mb-5 grid gap-2 sm:grid-cols-3">
        <Button
          fullWidth
          onClick={() =>
            redirectTo("/predictions")
          }
        >
          Make Predictions
        </Button>

        <Button
          fullWidth
          variant="secondary"
          onClick={() =>
            redirectTo("/leaderboard")
          }
        >
          View Leaderboard
        </Button>

        <Button
          fullWidth
          variant="secondary"
          onClick={() =>
            redirectTo("/")
          }
        >
          View Fixtures
        </Button>
      </div>

      <div className="mx-auto grid max-w-5xl gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Current Rank"
          value={`#${userRow?.rank ?? "-"}`}
          tone="navy"
        />

        <StatCard
          title="Rank Movement"
          value={renderMovement()}
          tone={
            rankMovement > 0
              ? "lime"
              : rankMovement < 0
                ? "orange"
                : "navy"
          }
        />

        <StatCard
          title="Total Points"
          value={
            userRow?.totalPoints ?? 0
          }
          tone="blue"
        />

        <StatCard
          title="Difference Score"
          value={
            userRow?.differenceScore ??
            0
          }
          tone="navy"
        />
      </div>

      <div className="mx-auto mt-4 grid max-w-5xl gap-3 md:grid-cols-3">
        <StatCard
          title="Exact Scores"
          value={
            userRow?.exactScores ?? 0
          }
          tone="lime"
        />

        <StatCard
          title="Prediction Progress"
          value={`${predictionCount} / ${matchCount}`}
          tone="orange"
        />

        <StatCard
          title="Players"
          value={leaderboard.length}
          tone="blue"
        />
      </div>

      <div className="mx-auto mt-5 grid max-w-5xl gap-4 md:grid-cols-2">
        <Card title="Next Match">
          {nextMatch ? (
            <div className="space-y-3">
              <div>
                <p className="text-lg font-semibold text-[var(--brand-navy)]">
                  {nextMatch.homeTeam.name}
                  {" vs "}
                  {nextMatch.awayTeam.name}
                </p>

                <p className="mt-1 text-sm text-[var(--brand-muted)]">
  Round{" "}
  {nextMatch.round ?? "-"}
</p>

                <p className="font-semibold text-[var(--brand-blue)]">
                  {nextMatch.kickoffTime
                    ? formatIrishDate(
                        nextMatch.kickoffTime
                      )
                    : "Kick-off time unavailable"}
                </p>
              </div>

              {nextMatch.kickoffTime && (
                <CountdownTimer
                  targetDate={
                    nextMatch.kickoffTime
                  }
                  label="Time until kick-off"
                />
              )}

              <Button
                fullWidth
                onClick={() =>
                  redirectTo(
                    "/predictions"
                  )
                }
              >
                Predict This Match
              </Button>
            </div>
          ) : (
            <p>
              Tournament Complete
            </p>
          )}
        </Card>

        <Card title="Latest Result">
          {lastMatch ? (
            <>
              <p className="text-lg font-semibold text-[var(--brand-navy)]">
                {lastMatch.homeTeam.name}{" "}
                {lastMatch.actualHomeScore ??
                  "-"}
                {" - "}
                {lastMatch.actualAwayScore ??
                  "-"}{" "}
                {lastMatch.awayTeam.name}
              </p>

              {lastPrediction && (
                <div className="mt-4 space-y-2 text-[var(--brand-muted)]">
                  <p>
                    Points Earned:{" "}
                    <span className="font-semibold text-[var(--brand-blue)]">
                      {lastPrediction.pointsAwarded ??
                        0}
                    </span>
                  </p>

                  <p>
                    Difference Score:{" "}
                    <span className="font-semibold text-[var(--brand-orange)]">
                      {lastPrediction.differenceScore ??
                        0}
                    </span>
                  </p>
                </div>
              )}
            </>
          ) : (
            <p>
              No completed matches
            </p>
          )}
        </Card>
      </div>
    </main>
  );
}