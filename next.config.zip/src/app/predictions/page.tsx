'use client';

import React, { useEffect, useState } from 'react';

export interface Fixture {
  id: string;
  homeTeam: string;
  awayTeam: string;
  kickoff: string;
}

export interface Prediction {
  fixtureId: string;
  homeScore: number;
  awayScore: number;
}

export default function PredictionsPage() {
  const [fixtures, setFixtures] = useState<Fixture[]>([]);
  const [predictions, setPredictions] = useState<Record<string, Prediction>>({});
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;

    async function fetchData() {
      try {
        const [fixturesRes, predictionsRes] = await Promise.all([
          fetch('/api/fixtures'),
          fetch('/api/predictions'),
        ]);

        if (!fixturesRes.ok || !predictionsRes.ok) {
          throw new Error('Failed to load predictions data.');
        }

        const fixturesData = await fixturesRes.json();
        const predictionsData = await predictionsRes.json();

        if (isMounted) {
          const sorted = Array.isArray(fixturesData)
            ? [...fixturesData].sort((a, b) => {
                const timeA = a?.kickoff ? new Date(a.kickoff).getTime() : 0;
                const timeB = b?.kickoff ? new Date(b.kickoff).getTime() : 0;
                return timeA - timeB;
              })
            : [];

          setFixtures(sorted);

          const predMap: Record<string, Prediction> = {};
          if (Array.isArray(predictionsData)) {
            predictionsData.forEach((p: Prediction) => {
              if (p?.fixtureId) predMap[p.fixtureId] = p;
            });
          }
          setPredictions(predMap);
          setLoading(false);
        }
      } catch (err: unknown) {
        if (isMounted) {
          setError(err instanceof Error ? err.message : 'An error occurred');
          setLoading(false);
        }
      }
    }

    fetchData();

    return () => {
      isMounted = false;
    };
  }, []);

  function formatKickoffDate(dateString: string) {
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return 'TBD';
      return new Intl.DateTimeFormat('en-IE', {
        dateStyle: 'medium',
        timeStyle: 'short',
        timeZone: 'Europe/Dublin',
      }).format(date);
    } catch {
      return 'TBD';
    }
  }

  if (loading) return <div>Loading predictions...</div>;
  if (error) return <div role="alert">Error: {error}</div>;

  return (
    <main style={{ padding: '2rem' }}>
      <h1>Six Nations Predictions</h1>
      <div>
        {fixtures.map((fixture) => (
          <div key={fixture.id} data-testid={`fixture-${fixture.id}`}>
            <h3>
              {fixture.homeTeam} vs {fixture.awayTeam}
            </h3>
            <p>Kickoff: {formatKickoffDate(fixture.kickoff)}</p>
            {predictions[fixture.id] && (
              <p>
                Predicted: {predictions[fixture.id].homeScore} - {predictions[fixture.id].awayScore}
              </p>
            )}
          </div>
        ))}
      </div>
    </main>
  );
}