"use client";

import Button from "@/components/ui/Button";
import Card from "@/components/ui/Card";
import PageHeader from "@/components/ui/PageHeader";
import {
  formatIrishDate,
  formatIsoDate,
} from "@/lib/formatIrishDate";
import { useEffect, useState } from "react";

type Person = {
  firstName?: string | null;
  lastName?: string | null;
};

type Team = {
  shortCode: string;
};

type AuditMatch = {
  homeTeam: Team;
  awayTeam: Team;
};

type AuditEntry = {
  id: number;
  matchId: number;
  previousHome?: number | null;
  previousAway?: number | null;
  newHome: number;
  newAway: number;
  adminUserId: number;
  createdAt: string;
  match?: AuditMatch | null;
  adminUser?: Person | null;
};

type AuditResponse = {
  audits?: AuditEntry[];
  totalPages?: number;
};

const PAGE_SIZE = 10;

async function readJson<T>(
  response: Response
): Promise<T> {
  return (await response.json()) as T;
}

function getAdminName(
  audit: AuditEntry
): string {
  const fullName = [
    audit.adminUser?.firstName,
    audit.adminUser?.lastName,
  ]
    .filter(Boolean)
    .join(" ")
    .trim();

  return (
    fullName ||
    String(audit.adminUserId)
  );
}

export default function AuditPage() {
  const [audits, setAudits] =
    useState<AuditEntry[]>([]);

  const [loading, setLoading] =
    useState(true);

  const [page, setPage] =
    useState(1);

  const [totalPages, setTotalPages] =
    useState(1);

  useEffect(() => {
    void loadAuditHistory(page);
  }, [page]);

  async function loadAuditHistory(
    currentPage: number
  ) {
    try {
      setLoading(true);

      const response = await fetch(
        `/api/admin/audit?page=${currentPage}&pageSize=${PAGE_SIZE}`
      );

      if (response.status === 401) {
        window.location.href =
          "/login";
        return;
      }

      if (response.status === 403) {
        window.location.href =
          "/dashboard";
        return;
      }

      const result =
        await readJson<AuditResponse>(
          response
        );

      setAudits(
        result.audits ?? []
      );

      setTotalPages(
        result.totalPages ?? 1
      );
    } catch (error) {
      console.error(
        "Audit history load failed:",
        {
          timestamp:
            formatIsoDate(
              new Date()
            ),
          error,
        }
      );
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <main className="bg-white p-8 text-[var(--brand-navy)]">
        <PageHeader
          title="Audit History"
          subtitle="Loading audit records..."
        />

        <div className="mx-auto max-w-5xl">
          <Card>
            Loading audit history...
          </Card>
        </div>
      </main>
    );
  }

  return (
    <main className="bg-white p-8 text-[var(--brand-navy)]">
      <PageHeader
        title="Audit History"
        subtitle="Track all administrative changes to tournament results"
      />

      <div className="mx-auto max-w-5xl">
        {audits.length === 0 ? (
          <Card title="Audit History">
            No audit records found.
          </Card>
        ) : (
          <>
            <Card title="Audit History">
              <div className="overflow-x-auto">
                <table className="w-full border border-[var(--brand-border)]">
                  <thead>
                    <tr className="bg-[var(--brand-soft-blue)] text-[var(--brand-navy)]">
                      <th className="border border-[var(--brand-border)] p-3">
                        Date
                      </th>

                      <th className="border border-[var(--brand-border)] p-3">
                        Match
                      </th>

                      <th className="border border-[var(--brand-border)] p-3">
                        Previous Score
                      </th>

                      <th className="border border-[var(--brand-border)] p-3">
                        New Score
                      </th>

                      <th className="border border-[var(--brand-border)] p-3">
                        Admin
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {audits.map(
                      (audit) => (
                        <tr
                          key={audit.id}
                          className="text-center"
                        >
                          <td className="border border-[var(--brand-border)] p-3 text-[var(--brand-blue)]">
                            {formatIrishDate(
                              audit.createdAt
                            )}
                          </td>

                          <td className="border border-[var(--brand-border)] p-3">
                            {audit.match
                              ? `${audit.match.homeTeam.shortCode} v ${audit.match.awayTeam.shortCode}`
                              : `Match ${audit.matchId}`}
                          </td>

                          <td className="border border-[var(--brand-border)] p-3 text-[var(--brand-muted)]">
                            {audit.previousHome ??
                              "-"}
                            {" - "}
                            {audit.previousAway ??
                              "-"}
                          </td>

                          <td className="border border-[var(--brand-border)] p-3 font-semibold text-[var(--brand-orange)]">
                            {audit.newHome}
                            {" - "}
                            {audit.newAway}
                          </td>

                          <td className="border border-[var(--brand-border)] p-3">
                            {getAdminName(
                              audit
                            )}
                          </td>
                        </tr>
                      )
                    )}
                  </tbody>
                </table>
              </div>
            </Card>

            <div className="mt-6 flex items-center justify-center gap-4">
              <Button
                variant="secondary"
                disabled={page === 1}
                onClick={() =>
                  setPage(
                    (currentPage) =>
                      currentPage - 1
                  )
                }
              >
                Previous
              </Button>

              <span className="text-[var(--brand-muted)]">
                Page {page} of{" "}
                {totalPages}
              </span>

              <Button
                variant="secondary"
                disabled={
                  page === totalPages
                }
                onClick={() =>
                  setPage(
                    (currentPage) =>
                      currentPage + 1
                  )
                }
              >
                Next
              </Button>
            </div>
          </>
        )}
      </div>
    </main>
  );
}