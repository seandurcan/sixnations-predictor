"use client";

import Card from "@/components/ui/Card";
import PageHeader from "@/components/ui/PageHeader";
import StatCard from "@/components/ui/StatCard";
import StatusBadge from "@/components/ui/StatusBadge";
import {
  formatIrishDate,
  formatIsoDate,
} from "@/lib/formatIrishDate";
import {
  type ComponentProps,
  useEffect,
  useState,
} from "react";

type StatusValue =
  ComponentProps<
    typeof StatusBadge
  >["status"];

type Metrics = {
  userCount: number;
  verifiedUserCount: number;
  predictionCount: number;
  completedFixtures: number;
  totalFixtures: number;
  remainingFixtures: number;
};

type Person = {
  firstName?: string | null;
  lastName?: string | null;
};

type LeaderboardEntry = Person & {
  id: number;
  totalPoints: number;
  exactScores?: number;
};

type Tournament = {
  name?: string | null;
  year?: number | null;
  status?: StatusValue | null;
};

type Winner = {
  finalPoints: number;
  user?: Person | null;
};

type AuditMatch = {
  homeTeam: {
    shortCode: string;
  };
  awayTeam: {
    shortCode: string;
  };
};

type AuditEntry = {
  id: number;
  matchId: number;
  previousHome?: number | null;
  previousAway?: number | null;
  newHome: number;
  newAway: number;
  adminUserId: number;
  createdAt: string;
  match?: AuditMatch | null;
  adminUser?: Person | null;
};

type AdminDashboardResponse = {
  metrics?: Partial<Metrics>;
  tournament?: Tournament | null;
  currentLeader?: LeaderboardEntry | null;
  leaderboard?: LeaderboardEntry[];
  winner?: Winner | null;
  recentAudits?: AuditEntry[];
};

const EMPTY_METRICS: Metrics = {
  userCount: 0,
  verifiedUserCount: 0,
  predictionCount: 0,
  completedFixtures: 0,
  totalFixtures: 0,
  remainingFixtures: 0,
};

async function readJson<T>(
  response: Response
): Promise<T> {
  return (await response.json()) as T;
}

function getPersonName(
  person: Person | null | undefined,
  fallback: string
): string {
  const name = [
    person?.firstName,
    person?.lastName,
  ]
    .filter(Boolean)
    .join(" ")
    .trim();

  return name || fallback;
}

export default function AdminDashboardPage() {
  const [loading, setLoading] =
    useState(true);

  const [data, setData] =
    useState<AdminDashboardResponse | null>(
      null
    );

  useEffect(() => {
    void loadDashboard();
  }, []);

  async function loadDashboard() {
    try {
      const response = await fetch(
        "/api/admin/dashboard"
      );

      if (response.status === 401) {
        window.location.href =
          "/login";
        return;
      }

      if (response.status === 403) {
        window.location.href =
          "/dashboard";
        return;
      }

      const result =
        await readJson<AdminDashboardResponse>(
          response
        );

      if (!response.ok) {
        throw new Error(
          "Failed to load the admin dashboard."
        );
      }

      setData(result);
    } catch (error) {
      console.error(
        "Admin dashboard load failed:",
        {
          timestamp:
            formatIsoDate(
              new Date()
            ),
          error,
        }
      );
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <main className="min-h-screen bg-white p-8 text-[var(--brand-navy)]">
        <PageHeader
          title="Admin Dashboard"
          subtitle="Loading tournament overview..."
        />

        <div className="mx-auto max-w-5xl">
          <Card>
            Loading dashboard...
          </Card>
        </div>
      </main>
    );
  }

  if (!data) {
    return (
      <main className="min-h-screen bg-white p-8 text-[var(--brand-navy)]">
        <PageHeader
          title="Admin Dashboard"
          subtitle="Tournament overview and administration"
        />

        <div className="mx-auto max-w-5xl">
          <Card>
            Failed to load dashboard.
          </Card>
        </div>
      </main>
    );
  }

  const metrics: Metrics = {
    ...EMPTY_METRICS,
    ...data.metrics,
  };

  const leaderboard =
    data.leaderboard ?? [];

  const recentAudits =
    data.recentAudits ?? [];

  const tournamentStatus =
    data.tournament?.status ??
    ("OPEN" as StatusValue);

  return (
    <main className="min-h-screen bg-white p-8 text-[var(--brand-navy)]">
      <PageHeader
        title="Admin Dashboard"
        subtitle="Tournament overview and administration"
      />

      <div className="mx-auto max-w-5xl">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Registered Users"
            value={metrics.userCount}
            tone="blue"
          />

          <StatCard
            title="Verified Users"
            value={
              metrics.verifiedUserCount
            }
            tone="lime"
          />

          <StatCard
            title="Predictions"
            value={
              metrics.predictionCount
            }
            tone="orange"
          />

          <StatCard
            title="Fixtures Complete"
            value={
              metrics.completedFixtures
            }
            subtitle={`of ${metrics.totalFixtures}`}
            tone="navy"
          />
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-2">
          <Card title="Tournament Status">
            <div className="space-y-3 text-[var(--brand-muted)]">
              <p>
                <strong className="text-[var(--brand-navy)]">
                  Name:
                </strong>{" "}
                {data.tournament?.name ??
                  "Not available"}
              </p>

              <p>
                <strong className="text-[var(--brand-navy)]">
                  Year:
                </strong>{" "}
                {data.tournament?.year ??
                  "Not available"}
              </p>

              <p>
                <strong className="text-[var(--brand-navy)]">
                  Status:
                </strong>{" "}
                <StatusBadge
                  status={
                    tournamentStatus
                  }
                />
              </p>

              <p>
                <strong className="text-[var(--brand-navy)]">
                  Remaining Fixtures:
                </strong>{" "}
                {
                  metrics.remainingFixtures
                }
              </p>
            </div>
          </Card>

          <Card title="Current Leader">
            {data.currentLeader ? (
              <>
                <p className="text-2xl font-semibold text-[var(--brand-navy)]">
                  {getPersonName(
                    data.currentLeader,
                    "Unknown Player"
                  )}
                </p>

                <p className="mt-3 text-[var(--brand-muted)]">
                  Points:{" "}
                  <strong className="text-[var(--brand-blue)]">
                    {
                      data.currentLeader
                        .totalPoints
                    }
                  </strong>
                </p>

                <p className="text-[var(--brand-muted)]">
                  Exact Scores:{" "}
                  <strong className="text-[var(--brand-navy)]">
                    {
                      data.currentLeader
                        .exactScores ?? 0
                    }
                  </strong>
                </p>
              </>
            ) : (
              <p>
                No leaderboard data available.
              </p>
            )}
          </Card>
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-2">
          <Card title="Top 10 Leaderboard">
            {leaderboard.length > 0 ? (
              <div className="space-y-3">
                {leaderboard.map(
                  (user, index) => (
                    <div
                      key={user.id}
                      className="flex items-center justify-between border-b border-[var(--brand-border)] pb-2"
                    >
                      <div>
                        <span className="font-semibold text-[var(--brand-blue)]">
                          #{index + 1}
                        </span>
                        {" "}
                        {getPersonName(
                          user,
                          "Unknown Player"
                        )}
                      </div>

                      <div className="font-bold text-[var(--brand-navy)]">
                        {
                          user.totalPoints
                        }
                      </div>
                    </div>
                  )
                )}
              </div>
            ) : (
              <p>
                No leaderboard data available.
              </p>
            )}
          </Card>

          {data.winner ? (
            <Card
              title="Tournament Winner"
              className="border-[rgba(157,255,0,0.75)] bg-[var(--brand-soft-lime)]"
            >
              <p className="text-xl font-semibold text-[var(--brand-navy)]">
                {getPersonName(
                  data.winner.user,
                  "Unknown Player"
                )}
              </p>

              <p className="mt-2 text-[var(--brand-muted)]">
                Final Points:{" "}
                <strong className="text-[var(--brand-blue)]">
                  {
                    data.winner
                      .finalPoints
                  }
                </strong>
              </p>
            </Card>
          ) : (
            <Card title="Tournament Winner">
              <p>
                Tournament not yet completed.
              </p>
            </Card>
          )}
        </div>

        <div className="mt-8">
          <Card title="Recent Audit Activity">
            {recentAudits.length === 0 ? (
              <p>
                No audit activity found.
              </p>
            ) : (
              <div className="space-y-4">
                {recentAudits.map(
                  (audit) => (
                    <div
                      key={audit.id}
                      className="border-b border-[var(--brand-border)] pb-4"
                    >
                      <div className="font-semibold text-[var(--brand-navy)]">
                        {audit.match
                          ? `${audit.match.homeTeam.shortCode} v ${audit.match.awayTeam.shortCode}`
                          : `Match ${audit.matchId}`}
                      </div>

                      <div className="mt-1 text-[var(--brand-muted)]">
                        {
                          audit.previousHome ??
                          "-"
                        }
                        {" - "}
                        {
                          audit.previousAway ??
                          "-"
                        }
                        {" → "}
                        <span className="font-semibold text-[var(--brand-orange)]">
                          {
                            audit.newHome
                          }
                          {" - "}
                          {
                            audit.newAway
                          }
                        </span>
                      </div>

                      <div className="mt-1 text-sm text-[var(--brand-muted)]">
                        Changed by{" "}
                        {getPersonName(
                          audit.adminUser,
                          `Admin ${audit.adminUserId}`
                        )}
                      </div>

                      <div className="text-sm text-[var(--brand-blue)]">
                        {formatIrishDate(
                          audit.createdAt
                        )}
                      </div>
                    </div>
                  )
                )}
              </div>
            )}
          </Card>
        </div>
      </div>
    </main>
  );
}