"use client";

import Alert from "@/components/ui/Alert";
import Button from "@/components/ui/Button";
import Card from "@/components/ui/Card";
import Input from "@/components/ui/Input";
import PageHeader from "@/components/ui/PageHeader";
import StatusBadge from "@/components/ui/StatusBadge";
import {
  formatIrishDate,
  formatIsoDate,
} from "@/lib/formatIrishDate";
import { useEffect, useState } from "react";

type UserRole = "ADMIN" | "USER";

type AuthResponse = {
  authenticated?: boolean;
  user?: {
    role?: UserRole;
  } | null;
};

type Team = {
  name: string;
  shortCode: string;
};

type Match = {
  id: number;
  round: number;
  kickoffTime?: string | null;
  completed: boolean;
  actualHomeScore?: number | null;
  actualAwayScore?: number | null;
  homeTeam: Team;
  awayTeam: Team;
};

type SaveResultResponse = {
  success?: boolean;
  error?: string;
};

type MatchStatus = "OPEN" | "COMPLETE";

async function readJson<T>(
  response: Response
): Promise<T> {
  return (await response.json()) as T;
}

function getKickoffTimestamp(
  match: Match
): number {
  if (!match.kickoffTime) {
    return Number.MAX_SAFE_INTEGER;
  }

  const timestamp = new Date(
    match.kickoffTime
  ).getTime();

  return Number.isFinite(timestamp)
    ? timestamp
    : Number.MAX_SAFE_INTEGER;
}

export default function AdminPage() {
  const [loading, setLoading] =
    useState(true);

  const [authorised, setAuthorised] =
    useState(false);

  const [matches, setMatches] =
    useState<Match[]>([]);

  const [
    selectedMatchId,
    setSelectedMatchId,
  ] = useState<number | null>(null);

  const [homeScore, setHomeScore] =
    useState("");

  const [awayScore, setAwayScore] =
    useState("");

  const [
    successMessage,
    setSuccessMessage,
  ] = useState("");

  const [
    errorMessage,
    setErrorMessage,
  ] = useState("");

  const [saving, setSaving] =
    useState(false);

  useEffect(() => {
    void initialise();
  }, []);

  async function initialise() {
    try {
      const meResponse =
        await fetch("/api/auth/me");

      if (!meResponse.ok) {
        window.location.href =
          "/login";
        return;
      }

      const me =
        await readJson<AuthResponse>(
          meResponse
        );

      if (!me.authenticated) {
        window.location.href =
          "/login";
        return;
      }

      if (
        me.user?.role !== "ADMIN"
      ) {
        window.location.href =
          "/dashboard";
        return;
      }

      setAuthorised(true);

      await loadMatches();
      setLoading(false);
    } catch (error) {
      console.error(
        "Admin results page load failed:",
        {
          timestamp:
            formatIsoDate(
              new Date()
            ),
          error,
        }
      );

      window.location.href =
        "/login";
    }
  }

  async function loadMatches() {
    const response = await fetch(
      "/api/admin/matches"
    );

    if (response.status === 401) {
      window.location.href =
        "/login";
      return;
    }

    if (response.status === 403) {
      window.location.href =
        "/dashboard";
      return;
    }

    const data =
      await readJson<Match[]>(
        response
      );

    if (!Array.isArray(data)) {
      throw new Error(
        "Admin matches API returned invalid data."
      );
    }

    const sortedData = [
      ...data,
    ].sort(
      (first, second) =>
        getKickoffTimestamp(first) -
        getKickoffTimestamp(second)
    );

    setMatches(sortedData);

    if (
      sortedData.length > 0 &&
      selectedMatchId === null
    ) {
      setSelectedMatchId(
        sortedData[0].id
      );
    }
  }

  function selectMatch(
    match: Match
  ) {
    setSelectedMatchId(match.id);

    setHomeScore(
      match.actualHomeScore?.toString() ??
        ""
    );

    setAwayScore(
      match.actualAwayScore?.toString() ??
        ""
    );

    setSuccessMessage("");
    setErrorMessage("");
  }

  async function saveResult() {
    if (
      selectedMatchId === null ||
      saving
    ) {
      return;
    }

    setSuccessMessage("");
    setErrorMessage("");
    setSaving(true);

    try {
      const response = await fetch(
        "/api/admin/results",
        {
          method: "POST",
          headers: {
            "Content-Type":
              "application/json",
          },
          body: JSON.stringify({
            matchId:
              selectedMatchId,
            homeScore:
              Number(homeScore),
            awayScore:
              Number(awayScore),
          }),
        }
      );

      if (response.status === 401) {
        window.location.href =
          "/login";
        return;
      }

      if (response.status === 403) {
        setErrorMessage(
          "Administrator access required."
        );

        window.location.href =
          "/dashboard";
        return;
      }

      const result =
        await readJson<SaveResultResponse>(
          response
        );

      if (result.success) {
        setSuccessMessage(
          "Result saved successfully."
        );

        setHomeScore("");
        setAwayScore("");

        await loadMatches();
        return;
      }

      setErrorMessage(
        result.error ??
          "Failed to save result."
      );
    } catch (error) {
      console.error(
        "Admin result save failed:",
        {
          timestamp:
            formatIsoDate(
              new Date()
            ),
          error,
        }
      );

      setErrorMessage(
        "Unable to save the result. Please try again."
      );
    } finally {
      setSaving(false);
    }
  }

  function getMatchStatus(
    match: Match
  ): MatchStatus {
    if (match.completed) {
      return "COMPLETE";
    }

    return "OPEN";
  }

  if (loading) {
    return (
      <main className="bg-white p-8 text-[var(--brand-navy)]">
        <PageHeader
          title="Admin Results Entry"
          subtitle="Loading result management..."
        />

        <Card>
          Loading...
        </Card>
      </main>
    );
  }

  if (!authorised) {
    return null;
  }

  const selectedMatch =
    matches.find(
      (match) =>
        match.id ===
        selectedMatchId
    );

  return (
    <main className="bg-white p-8 text-[var(--brand-navy)]">
      <PageHeader
        title="Admin Results Entry"
        subtitle="Manage match results and tournament scoring"
      />

      {successMessage && (
        <Alert
          variant="success"
          title="Result Saved"
          className="mb-4"
        >
          {successMessage}
        </Alert>
      )}

      {errorMessage && (
        <Alert
          variant="error"
          title="Save Failed"
          className="mb-4"
        >
          {errorMessage}
        </Alert>
      )}

      <div className="mx-auto max-w-5xl">
        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          <Card title="Fixtures">
            <div className="max-h-[700px] space-y-2 overflow-y-auto">
              {matches.map(
                (match) => (
                  <button
                    key={match.id}
                    type="button"
                    onClick={() =>
                      selectMatch(
                        match
                      )
                    }
                    className={`w-full cursor-pointer rounded border p-3 text-left transition-colors hover:bg-[var(--brand-soft-lime)] ${
                      selectedMatchId ===
                      match.id
                        ? "border-[var(--brand-blue)] bg-[var(--brand-soft-blue)]"
                        : "border-[var(--brand-border)]"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="font-semibold text-[var(--brand-navy)]">
                          Round{" "}
                          {match.round}
                        </div>

                        <div className="mt-1">
                          {
                            match
                              .homeTeam
                              .shortCode
                          }
                          {" v "}
                          {
                            match
                              .awayTeam
                              .shortCode
                          }
                        </div>

                        {match.kickoffTime && (
                          <div className="mt-1 text-sm text-[var(--brand-muted)]">
                            {formatIrishDate(
                              match.kickoffTime
                            )}
                          </div>
                        )}

                        {match.completed && (
                          <div className="mt-2 text-sm font-semibold text-[var(--brand-blue)]">
                            Result:{" "}
                            {
                              match
                                .actualHomeScore
                            }
                            {" - "}
                            {
                              match
                                .actualAwayScore
                            }
                          </div>
                        )}
                      </div>

                      <StatusBadge
                        status={getMatchStatus(
                          match
                        )}
                      />
                    </div>
                  </button>
                )
              )}
            </div>
          </Card>

          <Card
            title="Result Entry"
            className="md:col-span-2"
          >
            {selectedMatch ? (
              <>
                <div className="mb-6 rounded-lg border border-[var(--brand-border)] bg-[var(--brand-soft-blue)] p-4">
                  <h2 className="text-2xl font-bold text-[var(--brand-navy)]">
                    {
                      selectedMatch
                        .homeTeam
                        .name
                    }
                    {" vs "}
                    {
                      selectedMatch
                        .awayTeam
                        .name
                    }
                  </h2>

                  {selectedMatch.kickoffTime && (
                    <p className="mt-2 text-[var(--brand-muted)]">
                      Kick-off:{" "}
                      <span className="font-semibold text-[var(--brand-blue)]">
                        {formatIrishDate(
                          selectedMatch.kickoffTime
                        )}
                      </span>
                    </p>
                  )}

                  <div className="mt-3">
                    <StatusBadge
                      status={getMatchStatus(
                        selectedMatch
                      )}
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <Input
                    type="number"
                    placeholder={`${selectedMatch.homeTeam.name} Score`}
                    value={homeScore}
                    onChange={(event) =>
                      setHomeScore(
                        event.target.value
                      )
                    }
                  />

                  <Input
                    type="number"
                    placeholder={`${selectedMatch.awayTeam.name} Score`}
                    value={awayScore}
                    onChange={(event) =>
                      setAwayScore(
                        event.target.value
                      )
                    }
                  />

                  <Button
                    onClick={
                      saveResult
                    }
                    disabled={saving}
                  >
                    {saving
                      ? "Saving Result..."
                      : "Save Result"}
                  </Button>
                </div>
              </>
            ) : (
              <p className="text-[var(--brand-muted)]">
                Select a fixture to enter a result.
              </p>
            )}
          </Card>
        </div>
      </div>
    </main>
  );
}