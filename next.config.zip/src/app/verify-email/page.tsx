'use client';

import React, { useEffect, useState, use } from 'react';

interface VerifyEmailPageProps {
  searchParams?: Promise<{ token?: string }>;
}

export default function VerifyEmailPage({ searchParams }: VerifyEmailPageProps) {
  const resolvedParams = searchParams ? use(searchParams) : undefined;
  const token = resolvedParams?.token;

  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [message, setMessage] = useState<string>('Verifying your email...');

  useEffect(() => {
    let isMounted = true;

    if (!token) {
      setStatus('error');
      setMessage('Invalid or missing verification token.');
      return;
    }

    async function verifyToken() {
      try {
        const response = await fetch(`/api/auth/verify-email?token=${encodeURIComponent(token as string)}`);
        const data = await response.json().catch(() => ({}));

        if (!response.ok) {
          throw new Error(data.message || 'Verification failed');
        }

        if (isMounted) {
          setStatus('success');
          setMessage(data.message || 'Email successfully verified.');
        }
      } catch (err: unknown) {
        if (isMounted) {
          setStatus('error');
          setMessage(err instanceof Error ? err.message : 'Verification failed.');
        }
      }
    }

    verifyToken();

    return () => {
      isMounted = false;
    };
  }, [token]);

  return (
    <main style={{ padding: '2rem', textAlign: 'center' }}>
      <h1>Email Verification</h1>
      {status === 'loading' && <p role="status">{message}</p>}
      {status === 'success' && <p role="alert" style={{ color: 'green' }}>{message}</p>}
      {status === 'error' && <p role="alert" style={{ color: 'red' }}>{message}</p>}
    </main>
  );
}