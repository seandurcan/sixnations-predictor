import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { vi, describe, it, expect, beforeEach, afterEach } from 'vitest';

import VerifyEmailPage from './page';
import PredictionsPage from '../predictions/page';

vi.mock('next/navigation', () => ({
  useSearchParams: () => new URLSearchParams({ token: 'test-token' }),
  useRouter: () => ({ push: vi.fn(), replace: vi.fn() }),
}));

describe('VerifyEmailPage', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('renders and completes email verification state update inside act', async () => {
    global.fetch = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ message: 'Email verified successfully.' }),
    } as Response);

    render(<VerifyEmailPage searchParams={Promise.resolve({ token: 'test-token' })} />);

    await waitFor(() => {
      expect(screen.getByRole('alert')).toHaveTextContent('Email verified successfully.');
    });
  });

  it('handles invalid or missing token gracefully', async () => {
    render(<VerifyEmailPage searchParams={Promise.resolve({ token: '' })} />);

    await waitFor(() => {
      expect(screen.getByRole('alert')).toHaveTextContent('Invalid or missing verification token.');
    });
  });
});

describe('PredictionsPage', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('loads predictions and fixtures successfully without unhandled state updates', async () => {
    const mockFixtures = [
      { id: '1', homeTeam: 'Ireland', awayTeam: 'France', kickoff: '2027-02-06T15:00:00Z' },
    ];
    const mockPredictions = [
      { fixtureId: '1', homeScore: 24, awayScore: 20 },
    ];

    global.fetch = vi.fn().mockImplementation((url: string) => {
      if (url.includes('/api/fixtures')) {
        return Promise.resolve({
          ok: true,
          json: async () => mockFixtures,
        } as Response);
      }
      if (url.includes('/api/predictions')) {
        return Promise.resolve({
          ok: true,
          json: async () => mockPredictions,
        } as Response);
      }
      return Promise.reject(new Error('Unknown endpoint'));
    });

    render(<PredictionsPage />);

    await waitFor(() => {
      expect(screen.getByText('Ireland vs France')).toBeInTheDocument();
      expect(screen.getByText('Predicted: 24 - 20')).toBeInTheDocument();
    });
  });

  it('handles API failures gracefully when endpoints throw errors', async () => {
    global.fetch = vi.fn().mockResolvedValue({
      ok: false,
      json: async () => ({ message: 'Failed' }),
    } as Response);

    render(<PredictionsPage />);

    await waitFor(() => {
      expect(screen.getByRole('alert')).toHaveTextContent('Error: Failed to load predictions data.');
    });
  });
});