"use client";

import Alert from "@/components/ui/Alert";
import Button from "@/components/ui/Button";
import Card from "@/components/ui/Card";
import Input from "@/components/ui/Input";
import PasswordInput from "@/components/ui/PasswordInput";
import Link from "next/link";
import {
  type FormEvent,
  useState,
} from "react";

type RegisterResponse = {
  success?: boolean;
  error?: string;
};

type ResendVerificationResponse = {
  success?: boolean;
  error?: string;
};

type RegistrationForm = {
  firstName: string;
  lastName: string;
  email: string;
  mobile: string;
  password: string;
  confirmPassword: string;
};

const EMPTY_FORM: RegistrationForm = {
  firstName: "",
  lastName: "",
  email: "",
  mobile: "",
  password: "",
  confirmPassword: "",
};

async function readJson<T>(
  response: Response
): Promise<T | null> {
  return (await response
    .json()
    .catch(() => null)) as T | null;
}

export default function RegisterPage() {
  const [form, setForm] =
    useState<RegistrationForm>(
      EMPTY_FORM
    );

  const [error, setError] =
    useState("");

  const [success, setSuccess] =
    useState("");

  const [loading, setLoading] =
    useState(false);

  const [
    registrationComplete,
    setRegistrationComplete,
  ] = useState(false);

  const [
    registeredEmail,
    setRegisteredEmail,
  ] = useState("");

  const [
    resendLoading,
    setResendLoading,
  ] = useState(false);

  const [
    resendMessage,
    setResendMessage,
  ] = useState("");

  const [
    resendSucceeded,
    setResendSucceeded,
  ] = useState(false);

  const passwordsMatch =
    form.password ===
    form.confirmPassword;

  function isValidEmail(
    email: string
  ) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
      email
    );
  }

  function isValidMobile(
    mobile: string
  ) {
    return /^[0-9+\s()-]{7,20}$/.test(
      mobile
    );
  }

  function passwordMeetsCriteria(
    password: string
  ) {
    return (
      password.length >= 8 &&
      /[A-Z]/.test(password) &&
      /[a-z]/.test(password) &&
      /\d/.test(password) &&
      /[^A-Za-z0-9]/.test(password)
    );
  }

  function validateForm() {
    if (!form.firstName.trim()) {
      return "First name is required.";
    }

    if (!form.lastName.trim()) {
      return "Last name is required.";
    }

    if (!form.email.trim()) {
      return "Email is required.";
    }

    if (!isValidEmail(form.email)) {
      return "Enter a valid email address.";
    }

    if (!form.mobile.trim()) {
      return "Mobile number is required.";
    }

    if (!isValidMobile(form.mobile)) {
      return "Enter a valid mobile number.";
    }

    if (!form.password) {
      return "Password is required.";
    }

    if (
      !passwordMeetsCriteria(
        form.password
      )
    ) {
      return "Password must be at least 8 characters and include uppercase, lowercase, number, and special character.";
    }

    if (!form.confirmPassword) {
      return "Please confirm your password.";
    }

    if (!passwordsMatch) {
      return "Passwords do not match.";
    }

    return "";
  }

  async function handleSubmit(
    event: FormEvent<HTMLFormElement>
  ) {
    event.preventDefault();

    if (loading) {
      return;
    }

    setError("");
    setSuccess("");
    setResendMessage("");
    setResendSucceeded(false);

    const validationError =
      validateForm();

    if (validationError) {
      setError(validationError);
      return;
    }

    setLoading(true);

    const normalisedEmail =
      form.email
        .trim()
        .toLowerCase();

    try {
      const response = await fetch(
        "/api/register",
        {
          method: "POST",
          headers: {
            "Content-Type":
              "application/json",
          },
          body: JSON.stringify({
            ...form,
            firstName:
              form.firstName.trim(),
            lastName:
              form.lastName.trim(),
            email: normalisedEmail,
            mobile:
              form.mobile.trim(),
          }),
        }
      );

      const result =
        await readJson<RegisterResponse>(
          response
        );

      if (!response.ok) {
        setError(
          result?.error ??
            "Registration failed."
        );
        return;
      }

      setRegisteredEmail(
        normalisedEmail
      );

      setRegistrationComplete(true);

      setSuccess(
        "Registration successful. Please verify your email before logging in."
      );

      setForm(EMPTY_FORM);
    } catch (registrationError) {
      console.error(
        "Registration request failed:",
        registrationError
      );

      setError(
        "Unable to connect. Please try again."
      );
    } finally {
      setLoading(false);
    }
  }

  async function handleResendVerification() {
    if (
      resendLoading ||
      !registeredEmail
    ) {
      return;
    }

    setResendLoading(true);
    setResendMessage("");
    setResendSucceeded(false);

    try {
      const response = await fetch(
        "/api/auth/resend-verification",
        {
          method: "POST",
          headers: {
            "Content-Type":
              "application/json",
          },
          body: JSON.stringify({
            email: registeredEmail,
          }),
        }
      );

      const result =
        await readJson<ResendVerificationResponse>(
          response
        );

      if (
        response.ok &&
        result?.success === true
      ) {
        setResendSucceeded(true);

        setResendMessage(
          "Verification email sent. Please check your inbox."
        );

        return;
      }

      setResendMessage(
        result?.error ??
          "Unable to send verification email."
      );
    } catch (resendError) {
      console.error(
        "Verification resend failed:",
        resendError
      );

      setResendMessage(
        "Unable to send verification email."
      );
    } finally {
      setResendLoading(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center p-6">
      <Card className="w-full max-w-md">
        <form
          onSubmit={handleSubmit}
          className="space-y-4"
          noValidate
        >
          <h1 className="text-3xl font-bold">
            Register
          </h1>

          <p className="text-sm text-slate-600">
            Passwords must be at least
            8 characters and include
            uppercase, lowercase, a
            number, and a special
            character.
          </p>

          {success && (
            <Alert
              variant="success"
              title="Registration Successful"
            >
              {success}
            </Alert>
          )}

          {registrationComplete && (
            <Alert
              variant="warning"
              title="Verify Your Email"
            >
              <div className="space-y-2">
                <p>
                  Before you can log in,
                  you must verify your
                  email address.
                </p>

                <ol className="list-decimal pl-5">
                  <li>
                    Open your email inbox.
                  </li>
                  <li>
                    Find the verification
                    email from Six Nations
                    Predictor.
                  </li>
                  <li>
                    Click the Verify Email
                    button.
                  </li>
                  <li>
                    Return to the site.
                  </li>
                  <li>
                    Log in using your
                    email and password.
                  </li>
                </ol>

                <p>
                  If you do not receive
                  the email, check your
                  spam or junk folder.
                </p>
              </div>
            </Alert>
          )}

          {registrationComplete && (
            <Button
              type="button"
              variant="secondary"
              fullWidth
              disabled={resendLoading}
              onClick={
                handleResendVerification
              }
            >
              {resendLoading
                ? "Sending..."
                : "Resend Verification Email"}
            </Button>
          )}

          {resendMessage && (
            <Alert
              variant={
                resendSucceeded
                  ? "success"
                  : "error"
              }
              title={
                resendSucceeded
                  ? "Verification Email Sent"
                  : "Verification Email Failed"
              }
            >
              {resendMessage}
            </Alert>
          )}

          {registrationComplete && (
            <Link
              href="/login"
              className="inline-flex w-full items-center justify-center rounded-lg bg-[var(--brand-blue)] px-4 py-2 font-semibold text-white transition-colors duration-200 hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-[var(--brand-blue)] focus:ring-offset-2"
            >
              Go To Login
            </Link>
          )}

          {error && (
            <Alert
              variant="error"
              title="Registration Failed"
            >
              {error}
            </Alert>
          )}

          <Input
            name="firstName"
            placeholder="First Name"
            autoComplete="given-name"
            value={form.firstName}
            disabled={
              loading ||
              registrationComplete
            }
            onChange={(event) =>
              setForm((current) => ({
                ...current,
                firstName:
                  event.target.value,
              }))
            }
          />

          <Input
            name="lastName"
            placeholder="Last Name"
            autoComplete="family-name"
            value={form.lastName}
            disabled={
              loading ||
              registrationComplete
            }
            onChange={(event) =>
              setForm((current) => ({
                ...current,
                lastName:
                  event.target.value,
              }))
            }
          />

          <Input
            name="email"
            type="email"
            placeholder="Email"
            autoComplete="email"
            value={form.email}
            disabled={
              loading ||
              registrationComplete
            }
            onChange={(event) =>
              setForm((current) => ({
                ...current,
                email:
                  event.target.value,
              }))
            }
          />

          <Input
            name="mobile"
            type="tel"
            placeholder="Mobile"
            autoComplete="tel"
            value={form.mobile}
            disabled={
              loading ||
              registrationComplete
            }
            onChange={(event) =>
              setForm((current) => ({
                ...current,
                mobile:
                  event.target.value,
              }))
            }
          />

          <PasswordInput
            name="password"
            placeholder="Password"
            autoComplete="new-password"
            value={form.password}
            disabled={
              loading ||
              registrationComplete
            }
            showStrength
            showCriteria
            onChange={(event) =>
              setForm((current) => ({
                ...current,
                password:
                  event.target.value,
              }))
            }
          />

          <PasswordInput
            name="confirmPassword"
            placeholder="Confirm Password"
            autoComplete="new-password"
            value={form.confirmPassword}
            disabled={
              loading ||
              registrationComplete
            }
            onChange={(event) =>
              setForm((current) => ({
                ...current,
                confirmPassword:
                  event.target.value,
              }))
            }
          />

          {form.confirmPassword &&
            !passwordsMatch && (
              <Alert
                variant="warning"
                title="Validation"
              >
                Passwords do not match.
              </Alert>
            )}

          {!registrationComplete && (
            <Button
              type="submit"
              fullWidth
              disabled={loading}
            >
              {loading
                ? "Registering..."
                : "Register"}
            </Button>
          )}
        </form>
      </Card>
    </main>
  );
}