﻿param(
    [string]$ProjectRoot = "C:\Projects\sixnations-predictor"
)

$ErrorActionPreference = "Stop"

$protectedPaths = @(
    (Join-Path $ProjectRoot "src\components\layout\PageContainer.tsx"),
    (Join-Path $ProjectRoot "src\app\predictions\page.tsx"),
    (Join-Path $ProjectRoot "src\app\leaderboard\page.tsx")
)

$protectedHashes = @{}

foreach ($path in $protectedPaths) {
    if (-not (Test-Path -LiteralPath $path)) {
        throw "Protected file not found: $path"
    }

    $protectedHashes[$path] = (
        Get-FileHash -LiteralPath $path -Algorithm SHA256
    ).Hash
}

function Read-Utf8File {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        throw "File not found: $Path"
    }

    return [System.IO.File]::ReadAllText(
        $Path,
        [System.Text.Encoding]::UTF8
    )
}

function Write-Utf8File {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [string]$Content
    )

    $utf8WithoutBom = New-Object System.Text.UTF8Encoding($false)

    [System.IO.File]::WriteAllText(
        $Path,
        $Content,
        $utf8WithoutBom
    )
}

function Replace-RequiredText {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Content,

        [Parameter(Mandatory = $true)]
        [string]$Desired,

        [Parameter(Mandatory = $true)]
        [string[]]$AcceptedExisting,

        [Parameter(Mandatory = $true)]
        [string]$Description
    )

    if ($Content.Contains($Desired)) {
        Write-Host "Already correct: $Description" -ForegroundColor DarkYellow
        return $Content
    }

    foreach ($candidate in $AcceptedExisting) {
        if ($Content.Contains($candidate)) {
            Write-Host "Updating: $Description" -ForegroundColor Cyan
            return $Content.Replace($candidate, $Desired)
        }
    }

    throw "Could not locate the expected code for: $Description"
}

function Update-ProjectFile {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [scriptblock]$Transform
    )

    $original = Read-Utf8File -Path $Path
    $updated = & $Transform $original

    if ($updated -eq $original) {
        Write-Host "No file change required: $Path" -ForegroundColor DarkYellow
        return
    }

    $backup = "$Path.predictions-reference.bak"
    Copy-Item -LiteralPath $Path -Destination $backup -Force
    Write-Utf8File -Path $Path -Content $updated

    Write-Host "Updated: $Path" -ForegroundColor Green
    Write-Host "Backup:  $backup" -ForegroundColor DarkGray
}

$dashboardPath = Join-Path $ProjectRoot "src\app\dashboard\page.tsx"
$adminDashboardPath = Join-Path $ProjectRoot "src\app\admin\dashboard\page.tsx"
$adminResultsPath = Join-Path $ProjectRoot "src\app\admin\page.tsx"
$auditPath = Join-Path $ProjectRoot "src\app\admin\audit\page.tsx"

$dashboardTransform = {
    param($content)

    $content = Replace-RequiredText `
        -Content $content `
        -Desired '<div className="mx-auto grid max-w-5xl gap-4 md:grid-cols-2 lg:grid-cols-4">' `
        -AcceptedExisting @(
            '<div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">'
        ) `
        -Description "primary dashboard statistics grid"

    $content = Replace-RequiredText `
        -Content $content `
        -Desired '<div className="mx-auto mt-4 grid max-w-5xl gap-3 md:grid-cols-3">' `
        -AcceptedExisting @(
            '<div className="mt-4 grid gap-3 md:grid-cols-3">'
        ) `
        -Description "secondary dashboard statistics grid"

    $content = Replace-RequiredText `
        -Content $content `
        -Desired '<div className="mx-auto mt-5 grid max-w-5xl gap-4 md:grid-cols-2">' `
        -AcceptedExisting @(
            '<div className="mt-5 grid gap-4 md:grid-cols-2">'
        ) `
        -Description "dashboard lower card grid"

    return $content
}

Update-ProjectFile `
    -Path $dashboardPath `
    -Transform $dashboardTransform

Update-ProjectFile `
    -Path $adminDashboardPath `
    -Transform $dashboardTransform

Update-ProjectFile `
    -Path $adminResultsPath `
    -Transform {
        param($content)

        return Replace-RequiredText `
            -Content $content `
            -Desired '<div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-3">' `
            -AcceptedExisting @(
                '<div className="grid grid-cols-1 gap-6 md:grid-cols-3">',
                '<div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(340px,1.15fr)_minmax(0,1.85fr)]">'
            ) `
            -Description "Admin Results main grid"
    }

Update-ProjectFile `
    -Path $auditPath `
    -Transform {
        param($content)

        return Replace-RequiredText `
            -Content $content `
            -Desired '<Card title="Audit History" className="mx-auto max-w-5xl">' `
            -AcceptedExisting @(
                '<Card title="Audit History">',
                '<Card title="Audit History" className="w-full">'
            ) `
            -Description "Audit History card"
    }

foreach ($path in $protectedPaths) {
    $afterHash = (
        Get-FileHash -LiteralPath $path -Algorithm SHA256
    ).Hash

    if ($afterHash -ne $protectedHashes[$path]) {
        throw "Protected file changed unexpectedly: $path"
    }

    Write-Host "Verified unchanged: $path" -ForegroundColor Green
}

Write-Host ""
Write-Host "Predictions-reference layout pass complete." -ForegroundColor Cyan
Write-Host "PageContainer, Predictions and Leaderboard were not changed." -ForegroundColor Cyan
Write-Host ""
Write-Host "Run:" -ForegroundColor White
Write-Host "npm test -- --run src/app/dashboard/page.test.tsx" -ForegroundColor Gray
Write-Host "npm test -- --run src/app/admin/dashboard/page.test.tsx" -ForegroundColor Gray
Write-Host "npm test -- --run src/app/admin/page.test.tsx" -ForegroundColor Gray
Write-Host "npm test -- --run src/app/admin/audit/page.test.tsx" -ForegroundColor Gray
