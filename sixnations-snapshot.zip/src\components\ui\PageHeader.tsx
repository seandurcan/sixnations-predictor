type PageHeaderProps = {
  title: string;
  subtitle?: string;
  className?: string;
};

export default function PageHeader({
  title,
  subtitle,
  className = "",
}: PageHeaderProps) {
  return (
    <div className={className}>
      <h1 className="text-4xl font-bold text-[var(--brand-navy)]">
        {title}
      </h1>

      {subtitle && (
        <p className="mt-2 text-[var(--brand-muted)]">
          {subtitle}
        </p>
      )}
    </div>
  );
}